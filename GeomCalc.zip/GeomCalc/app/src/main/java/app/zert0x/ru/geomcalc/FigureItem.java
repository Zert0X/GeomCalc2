package app.zert0x.ru.geomcalc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class FigureItem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_figure_item);
    }
}
