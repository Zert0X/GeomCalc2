package app.zert0x.ru.geomcalc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static app.zert0x.ru.geomcalc.MainActivity.*;
public class Choose extends AppCompatActivity {
 ArrayList<String>SpinerArr = new ArrayList<>();
 ImageView Image1;
  int pos_figure;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);

        SpinerArr.clear();
findViews();
        Image1.setImageResource(FigureArr.get(pos).image);
        pos_figure = 0;
        switch(figure){
            case "Квадрат": Square_fill();break;
            case "Прямоугольник": Rectangle_fill();break;
            case "Треугольник": Triangle_fill();break;
            case "Трапеция": Trapezium_fill();break;
            case "Параллелограмм": Parallelogram_fill();break;
            case "Кольцо": Ring_fill();break;
            case "Круг": Circle_fill();break;
            case "Правильный многоугольник": Regular_Polygon_fill();break;
            case "Сектор круга": Circular_Sector_fill();break;
            case "Ромб": Rhombus_fill();break;
            case "Куб": Cube_fill();break;
            case "Шар": Sphere_fill();break;
            case "Параллелепипед": Parallelepiped_fill();break;
            case "Конус": Cone_fill();break;
            case "Призма": Prism_fill();break;
            case "Пирамида": Pyramid_fill();break;
            case "Тор": Torus_fill();break;
            case "Тетраэдр": Tetrahedron_fill();break;
            case "Цилиндр": Cylinder_fill();break;
        }
        Figure_choosed();
        Spinner();

    }
    void Figure_choosed(){
        switch(figure){
            case "Квадрат":

                Square_image();
                Square_result();
                break;
            case "Прямоугольник":

                Rectangle_image();
                Rectangle_result();
                break;
            case "Треугольник":

                Triangle_image();
                Triangle_result();
                break;
            case "Трапеция":

                Trapezium_image();
                Trapezium_result();
                break;
            case "Параллелограмм":

                Parallelogram_image();
                Parallelogram_result();
                break;
            case "Кольцо":

                Ring_image();
                Ring_result();
                break;
            case "Круг":

                Circle_image();
                Circle_result();
                break;
            case "Правильный многоугольник":

                Regular_Polygon_image();
                Regular_Polygon_result();
                break;
            case "Сектор круга":

                Circular_Sector_image();
                Circular_Sector_result();
                break;
            case "Ромб":

                Rhombus_image();
                Rhombus_result();
                break;
            case "Куб":

                Cube_image();
                Cube_result();
                break;
            case "Шар":

                Sphere_image();
                Sphere_result();
                break;
            case "Параллелепипед":

                Parallelepiped_image();
                Parallelepiped_result();
                break;
            case "Конус":

                Cone_image();
                Cone_result();
                break;
            case "Призма":

                Prism_image();
                Prism_result();
                break;
            case "Пирамида":

                Pyramid_image();
                Pyramid_result();
                break;
            case "Тор":

                Torus_image();
                Torus_result();
                break;
            case "Тетраэдр":

                Tetrahedron_image();
                Tetrahedron_result();
                break;
            case "Цилиндр":

                Cylinder_image();
                Cylinder_result();
                break;
        }
    }
    //////////////////////////////////////////////////////////////////////////////////////
    //<Figure>_fill   - Fill massive SpinnerArr with variants of available variables    //
    //<Figure>_image  - Select image to variant of available variables                  //
    //<Figure>_result - Math method which calculating result from available variables   //
    //////////////////////////////////////////////////////////////////////////////////////
    void Square_fill(){
        SpinerArr.add("Cторону"          );
        SpinerArr.add("Площадь"          );
        SpinerArr.add("Диагональ"        );
        SpinerArr.add("Периметр"         );
        SpinerArr.add("Радиус вписанной" );
        SpinerArr.add("Радиус описанной" );
    }
    void Square_image(){
        switch (pos_figure){
            case 0:Image1.setImageResource(R.drawable.square_side);break;
            case 1:Image1.setImageResource(R.drawable.square_area);break;
            case 2:Image1.setImageResource(R.drawable.square_diagonal);break;
            case 3:Image1.setImageResource(R.drawable.square_perimeter);break;
            case 4:Image1.setImageResource(R.drawable.square_the_radius_of_the_inscribed_circle);break;
            case 5:Image1.setImageResource(R.drawable.square_the_radius_of_the_circle);break;
        }
            }
    void Square_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Triangle_fill(){
        SpinerArr.add("Cтороны"            );
        SpinerArr.add("Два угла и сторону" );
        SpinerArr.add("Две стороны и угол" );
        SpinerArr.add("Основание и высоту" );

    }
    void Triangle_image(){}
    void Triangle_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Rectangle_fill(){
        SpinerArr.add("Стороны"                );
        SpinerArr.add("Площадь и Сторону"      );
        SpinerArr.add("Диагональ и Сторону"    );
        SpinerArr.add("Периметр и Диагональ"   );
        SpinerArr.add("Угол между Диагоналями" );
        SpinerArr.add("Угол от Даигонали"      );
    }
    void Rectangle_image(){}
    void Rectangle_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Trapezium_fill(){
        SpinerArr.add("Стороны"                 );
        SpinerArr.add("Равнобедреная трапеция"  );
        SpinerArr.add("Прямоугольная трапеция"  );
        SpinerArr.add("Среднюю линию и высоту"  );
    }
    void Trapezium_image(){}
    void Trapezium_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Parallelogram_fill(){
        SpinerArr.add("Стороны и высоту"    );
        SpinerArr.add("Стороны и угол"      );
        SpinerArr.add("Диагонали и угол"    );
        SpinerArr.add("Диагонали и сторону" );
        SpinerArr.add("Высоту и угол"       );
        SpinerArr.add("Сторону и угол"      );
    }
    void Parallelogram_image(){}
    void Parallelogram_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Ring_fill(){
        SpinerArr.add("Радиус"        );
        SpinerArr.add("Диаметр"       );
        SpinerArr.add("Окружность"    );
        SpinerArr.add("Сектор кольца" );
    }
    void Ring_image(){}
    void Ring_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Circle_fill(){
        SpinerArr.add("Диаметр" );
        SpinerArr.add("Радиус"  );
        SpinerArr.add("Площадь" );
        SpinerArr.add("Перимет" );


    }
    void Circle_image(){}
    void Circle_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Regular_Polygon_fill(){
        SpinerArr.add("Стороны"                    );
        SpinerArr.add("Площадь"                    );
        SpinerArr.add("Угол и сторону"             );
        SpinerArr.add("Радиус вписанной окружности");
        SpinerArr.add("Радиус описанной окружности");
    }
    void Regular_Polygon_image(){}
    void Regular_Polygon_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Circular_Sector_fill(){
        SpinerArr.add("Радиус и угол"       );
        SpinerArr.add("Длину дуги и радиус" );
        SpinerArr.add("Угол и длину дуги"   );
    }
    void Circular_Sector_image(){}
    void Circular_Sector_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Rhombus_fill(){
        SpinerArr.add("Сторону и высоту"    );
        SpinerArr.add("Площадь и угол"      );
        SpinerArr.add("Площадь и диагональ" );
        SpinerArr.add("Сторону и угол"      );
        SpinerArr.add("Диагонали"           );
        SpinerArr.add("Площадь и сторону"   );
        SpinerArr.add("Диагональ и сторону" );
        SpinerArr.add("Радиус и сторону"    );
        SpinerArr.add("Радиус и угол"       );
    }
    void Rhombus_image(){}
    void Rhombus_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Cube_fill(){
        SpinerArr.add("Ребро"                       );
        SpinerArr.add("Площадь куба"                );
        SpinerArr.add("Площадь боковой поверхности" );
        SpinerArr.add("Площадь стороны"             );
        SpinerArr.add("Объём"                       );
        SpinerArr.add("Периметр стороны"            );
        SpinerArr.add("Диагональ куба"              );
        SpinerArr.add("Диагональ стороны"           );
        SpinerArr.add("Радиус вписанной сферы"      );
        SpinerArr.add("Радиус описанной сферы"      );
    }
    void Cube_image(){}
    void Cube_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Sphere_fill(){
        SpinerArr.add("Радиус"              );
        SpinerArr.add("Объём"               );
        SpinerArr.add("Площадь поверхности" );
        SpinerArr.add("Диаметр"             );
        SpinerArr.add("Окружнесть"          );
        SpinerArr.add("Шаровой сегмент"     );
        SpinerArr.add("Шаровой сектор"      );
        SpinerArr.add("Шаровой слой"        );
    }
    void Sphere_image(){}
    void Sphere_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Parallelepiped_fill(){
        SpinerArr.add("Рёбра"     );
        SpinerArr.add("Диагональ" );
    }
    void Parallelepiped_image(){}
    void Parallelepiped_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Cone_fill(){
        SpinerArr.add("Радиус и образующую"            );
        SpinerArr.add("Радиус и высоту"                );
        SpinerArr.add("Образующую и высоту"            );
        SpinerArr.add("Объём и высоту"                 );
        SpinerArr.add("Угол раствора и образующую"     );
        SpinerArr.add("Угол раствора и высоту"         );
        SpinerArr.add("Угол раствора и радиус"         );
        SpinerArr.add("Площадь основания и образующую" );
        SpinerArr.add("Площадь основания и высоту"     );
    }
    void Cone_image(){}
    void Cone_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Prism_fill(){
        SpinerArr.add("Рёбра"                          );
        SpinerArr.add("Рёбра и высоту"                 );
        SpinerArr.add("Диагональ и ребро"              );
        SpinerArr.add("Радиус описанной сферы и ребро" );
    }
    void Prism_image(){}
    void Prism_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Pyramid_fill(){
        SpinerArr.add("Высоту и сторону основания"  );
        SpinerArr.add("Ребро и сторону основания"   );
        SpinerArr.add("Апофему и сторону основания" );
        SpinerArr.add("Периметр и апофему"          );
        SpinerArr.add("Площадь и высоту"            );
    }
    void Pyramid_image(){}
    void Pyramid_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Torus_fill(){
        SpinerArr.add("Радиус"     );
        SpinerArr.add("Окружность" );
    }
    void Torus_image(){}
    void Torus_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Tetrahedron_fill(){
        SpinerArr.add("Ребро"                  );
        SpinerArr.add("Объём"                  );
        SpinerArr.add("Площадь"                );
        SpinerArr.add("Длину ребёр"            );
        SpinerArr.add("Высоту"                 );
        SpinerArr.add("Радиус вписанной сферы" );
        SpinerArr.add("Радиус описанной сферы" );
    }
    void Tetrahedron_image(){}
    void Tetrahedron_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Cylinder_fill(){
        SpinerArr.add("Радиус и высоту"            );
        SpinerArr.add("Радиус и объём"             );
        SpinerArr.add("Радиус и диагональ"         );
        SpinerArr.add("Высоту и площадь основания" );
        SpinerArr.add("Высоту и диагональ"         );
        SpinerArr.add("Диаметр и высоту"           );
        SpinerArr.add("Диаметр и объём"            );
        SpinerArr.add("Диаметр и диагональ"        );
    }
    void Cylinder_image(){}
    void Cylinder_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Spinner(){
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, SpinerArr);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setAdapter(adapter);
        // заголовок
        spinner.setPrompt("Title");
        // выделяем элемент
        spinner.setSelection(0);
        // устанавливаем обработчик нажатия
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // показываем позиция нажатого элемента
                pos_figure=position;
                Figure_choosed();
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
    }
    void findViews(){
        Image1=findViewById(R.id.imageView3);
    }
}
