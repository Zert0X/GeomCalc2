package app.zert0x.ru.geomcalc;

import android.app.ActionBar;
import android.content.Intent;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static app.zert0x.ru.geomcalc.MainActivity.*;
import static java.lang.Math.*;

public class Choose extends AppCompatActivity {
 ArrayList<String>SpinerArr = new ArrayList<>();
 ImageView Image1;
    String result;

 EditText edit1,edit2,edit3,edit4;
 Button result_btn;
 Intent i;
  int pos_figure;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);

        i = new Intent(this,Result.class);


        SpinerArr.clear();
findViews();
        Image1.setImageResource(FigureArr.get(pos).image);
        pos_figure = 0;
        Figure_fill();
        Figure_image();
        Spinner();

    }
    //////////////////////////////////////////////////////////////////////////////////////
    //<Figure>_fill   - Fill massive SpinnerArr with variants of available variables    //
    //<Figure>_image  - Select image to variant of available variables                  //
    //<Figure>_result - Math method which calculating result from available variables   //
    //////////////////////////////////////////////////////////////////////////////////////
    void Figure_fill(){
        switch(figure){
            case "Квадрат": Square_fill();break;
            case "Прямоугольник": Rectangle_fill();break;
            case "Треугольник": Triangle_fill();break;
            case "Трапеция": Trapezium_fill();break;
            case "Параллелограмм": Parallelogram_fill();break;
            case "Кольцо": Ring_fill();break;
            case "Круг": Circle_fill();break;
            case "Правильный многоугольник": Regular_Polygon_fill();break;
            case "Сектор круга": Circular_Sector_fill();break;
            case "Ромб": Rhombus_fill();break;
            case "Куб": Cube_fill();break;
            case "Шар": Sphere_fill();break;
            case "Параллелепипед": Parallelepiped_fill();break;
            case "Конус": Cone_fill();break;
            case "Призма": Prism_fill();break;
            case "Пирамида": Pyramid_fill();break;
            case "Тор": Torus_fill();break;
            case "Тетраэдр": Tetrahedron_fill();break;
            case "Цилиндр": Cylinder_fill();break;
        }
    }
    void Figure_image(){
        switch(figure){
            case "Квадрат":Square_image();break;
            case "Прямоугольник":Rectangle_image();break;
            case "Треугольник":Triangle_image();break;
            case "Трапеция":Trapezium_image();break;
            case "Параллелограмм":Parallelogram_image();break;
            case "Кольцо":Ring_image();break;
            case "Круг":Circle_image();break;
            case "Правильный многоугольник":Regular_Polygon_image();break;
            case "Сектор круга":Circular_Sector_image();break;
            case "Ромб":Rhombus_image();break;
            case "Куб":Cube_image();break;
            case "Шар":Sphere_image();break;
            case "Параллелепипед":Parallelepiped_image();break;
            case "Конус":Cone_image();break;
            case "Призма":Prism_image();break;
            case "Пирамида":Pyramid_image();break;
            case "Тор":Torus_image();break;
            case "Тетраэдр":Tetrahedron_image();break;
            case "Цилиндр":Cylinder_image();break;
        }
    }
    void Figure_result(){
        switch(figure){
            case "Квадрат"                  : Square_result();                  break;
            case "Прямоугольник"            : Rectangle_result();               break;
            case "Треугольник"              : Triangle_result();                break;
            case "Трапеция"                 : Trapezium_result();               break;
            case "Параллелограмм"           : Parallelogram_result();           break;
            case "Кольцо"                   : Ring_result();                    break;
            case "Круг"                     : Circle_result();                  break;
            case "Правильный многоугольник" : Regular_Polygon_result();         break;
            case "Сектор круга"             : Circular_Sector_result();         break;
            case "Ромб"                     : Rhombus_result();                 break;
            case "Куб"                      : Cube_result();                    break;
            case "Шар"                      : Sphere_result();                  break;
            case "Параллелепипед"           : Parallelepiped_result();          break;
            case "Конус"                    : Cone_result();                    break;
            case "Призма"                   : Prism_result();                   break;
            case "Пирамида"                 : Pyramid_result();                 break;
            case "Тор"                      : Torus_result();                   break;
            case "Тетраэдр"                 : Tetrahedron_result();             break;
            case "Цилиндр"                  : Cylinder_result();                break;
        }
    }
    //////////////////////////////////////////////////////////////////////////////////////
    void Square_fill(){
        SpinerArr.add("Cторону"                     );
        SpinerArr.add("Площадь"                     );
        SpinerArr.add("Диагональ"                   );
        SpinerArr.add("Периметр"                    );
        SpinerArr.add("Радиус вписанной окружности" );
        SpinerArr.add("Радиус описанной окружности" );
    }
    void Square_image(){
        switch (pos_figure){
            case 0: Image1.setImageResource(R.drawable.square_side);
                    edit1.setHint("Сторона а");
                    edit1.setVisibility(View.VISIBLE);
                    edit2.setVisibility(View.INVISIBLE);
                    edit3.setVisibility(View.INVISIBLE);
                    edit4.setVisibility(View.INVISIBLE);
            break;
            case 1: Image1.setImageResource(R.drawable.square_area);
                edit1.setHint("Площадь квадтрата");
                edit1.setVisibility(View.VISIBLE);
                edit2.setVisibility(View.INVISIBLE);
                edit3.setVisibility(View.INVISIBLE);
                edit4.setVisibility(View.INVISIBLE);break;
            case 2: Image1.setImageResource(R.drawable.square_diagonal);
                edit1.setHint("Диагональ");
                edit1.setVisibility(View.VISIBLE);
                edit2.setVisibility(View.INVISIBLE);
                edit3.setVisibility(View.INVISIBLE);
                edit4.setVisibility(View.INVISIBLE);break;
            case 3: Image1.setImageResource(R.drawable.square_perimeter);
                edit1.setHint("Периметр");
                edit1.setVisibility(View.VISIBLE);
                edit2.setVisibility(View.INVISIBLE);
                edit3.setVisibility(View.INVISIBLE);
                edit4.setVisibility(View.INVISIBLE);break;
            case 4: Image1.setImageResource(R.drawable.square_the_radius_of_the_inscribed_circle);
                edit1.setHint("Радиус вписанной окружности");
                edit1.setVisibility(View.VISIBLE);
                edit2.setVisibility(View.INVISIBLE);
                edit3.setVisibility(View.INVISIBLE);
                edit4.setVisibility(View.INVISIBLE);break;
            case 5: Image1.setImageResource(R.drawable.square_the_radius_of_the_circle);
                edit1.setHint("Радиус описанной окружности");
                edit1.setVisibility(View.VISIBLE);
                edit2.setVisibility(View.INVISIBLE);
                edit3.setVisibility(View.INVISIBLE);
                edit4.setVisibility(View.INVISIBLE);break;
        }
            }
    void Square_result(){
        double s,p,d,R,r,a;

        s=0;p=0;d=0;R=0;r=0;a=0;
        switch(pos_figure){
            case 0:
                a=Double.valueOf(String.valueOf(edit1.getText()));
                s=a*a;
                p=a*4;
                d=a*sqrt(2);
                R=a/sqrt(2);
                r=a/2;
                break;
            case 1:
                s=Double.valueOf(String.valueOf(edit1.getText()));
                a=sqrt(s);
                p=a*4;
                d=a*sqrt(2);
                R=a/sqrt(2);
                r=a/2;
                break;
            case 2:
                d=Double.valueOf(String.valueOf(edit1.getText()));
                a=d/sqrt(2);
                s=a*a;
                p=a*4;
                R=a/sqrt(2);
                r=a/2;
                break;
            case 3:
                p=Double.valueOf(String.valueOf(edit1.getText()));
                a=p/4;
                s=a*a;
                d=a*sqrt(2);
                R=a/sqrt(2);
                r=a/2;
                break;
            case 4:
                r=Double.valueOf(String.valueOf(edit1.getText()));
                a=r*2;
                s=a*a;
                p=a*4;
                d=a*sqrt(2);
                R=a/sqrt(2);
                break;
            case 5:
                R=Double.valueOf(String.valueOf(edit1.getText()));
                a=R*sqrt(2);
                s=a*a;
                p=a*4;
                d=a*sqrt(2);
                r=a/2;
            break;
        }
        result="Сторона а: "+a+"\n"+"Площадь: "+s+"\n"+"Периметр: "+p+"\n"+"Диагональ: "+d+"\n"+"Радиус описанной окружности: "+R+"\n"+"Радиус вписанной окружности: "+r;

    }
    //////////////////////////////////////////////////////////////////////////////////////
    void Triangle_fill(){
        SpinerArr.add("Cтороны"            );
        SpinerArr.add("Два угла и сторону" );
        SpinerArr.add("Две стороны и угол" );
        SpinerArr.add("Основание и высоту" );

    }
    void Triangle_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.triangle_sides);
                edit1.setVisibility(View.VISIBLE);
                edit1.setHint("Сторона а");
                edit2.setVisibility(View.VISIBLE);
                edit2.setHint("Сторона b");
                edit3.setVisibility(View.VISIBLE);
                edit3.setHint("Сторона c");
                edit4.setVisibility(View.INVISIBLE);break;
            case 1:Image1.setImageResource(R.drawable.triangle_two_angles_and_side_c);
                edit1.setVisibility(View.VISIBLE);
                edit1.setHint("Угол α в градусах");
                edit2.setVisibility(View.VISIBLE);
                edit2.setHint("Угол β в градусах");
                edit3.setVisibility(View.VISIBLE);
                edit3.setHint("Сторона c");
                edit4.setVisibility(View.INVISIBLE);break;
            case 2:Image1.setImageResource(R.drawable.triangle_angle_and_two_sides);
                edit1.setVisibility(View.VISIBLE);
                edit1.setHint("Сторона a");
                edit2.setVisibility(View.VISIBLE);
                edit2.setHint("Сторона c");
                edit3.setVisibility(View.VISIBLE);
                edit3.setHint("Угол α в градусах");
                edit4.setVisibility(View.INVISIBLE);break;
            case 3:Image1.setImageResource(R.drawable.area_triangle);
                edit1.setVisibility(View.VISIBLE);
                edit1.setHint("Высота h");
                edit2.setVisibility(View.VISIBLE);
                edit2.setHint("Сторона а");
                edit3.setVisibility(View.INVISIBLE);
                edit4.setVisibility(View.INVISIBLE);break;
        }
    }
    void Triangle_result(){
        double a,b,c,S,gama,beta,alpha,h,p,m_a,m_b,m_c,l_a,l_b,l_c,h_a,h_b,h_c,M_a,M_b,M_c,r,R;
        a=0;
        b=0;
        c=0;
        S=0;
        gama=0;
        beta=0;
        alpha=0;
        h=0;
        p=0;
        m_a=0;
        m_b=0;
        m_c=0;
        l_a=0;
        l_b=0;
        l_c=0;
        h_a=0;
        h_b=0;
        h_c=0;
        switch(pos_figure){
            case 0:

                    a = Double.valueOf(String.valueOf(edit1.getText()));
                    b = Double.valueOf(String.valueOf(edit2.getText()));
                    c = Double.valueOf(String.valueOf(edit3.getText()));
                    p = (a + b + c) / 2;
                    S = sqrt(p * (p - a) * (p - b) * (p - c));
                    alpha = Math.toDegrees(acos((-pow(b, 2) + pow(c, 2) + pow(a, 2)) / (2 * a * c)));
                    beta = Math.toDegrees(acos((pow(a, 2) - pow(c, 2) + pow(b, 2)) / (2 * a * b)));
                    gama = Math.toDegrees(acos((pow(b, 2) - pow(a, 2) + pow(c, 2)) / (2 * c * b)));
                    m_a = sqrt(2 * (b * b) + 2 * (c * c) - (a * a)) / 2;
                    m_b = sqrt(2 * (a * a) + 2 * (c * c) - (b * b)) / 2;
                    m_c = sqrt(2 * (a * a) + 2 * (b * b) - (c * c)) / 2;
                    l_a = sqrt(b * c * (a + b + c) * (b + c - a)) / (b + c);
                    l_b = sqrt(a * c * (a + b + c) * (a + c - b)) / (a + c);
                    l_c = sqrt(a * b * (a + b + c) * (a + b - c)) / (a + b);
                    h_a = (2 * sqrt(p * (p - a) * (p - b) * (p - c))) / a;
                    h_b = (2 * sqrt(p * (p - a) * (p - b) * (p - c))) / b;
                    h_c = (2 * sqrt(p * (p - a) * (p - b) * (p - c))) / c;
                    M_a = a / 2;
                    M_b = b / 2;
                    M_c = c / 2;
                    r = sqrt(((p - a) * (p - b) * (p - c)) / p);
                    R = a * b * c / (4 * sqrt(p * (p - a) * (p - b) * (p - c)));
                    if(((a+b>c)&&(a+c>b)&&(b+c>a))&&(Math.round(alpha+beta+gama)<=181)) {
                    result = "Сторона а: " + a + "\n" + "Сторона b: " + b + "\n" + "Сторона c: " + c + "\n" +
                            "Угол α: " + alpha + "\n" + "Угол β: " + beta + "\n" + "Угол γ: " + gama + "\n" +
                            "Площадь: " + S + "\n" + "Периметр: " + (p * 2) + "\n" +
                            "Высота треугольника h_a: " + h_a + "\n" + "Высота треугольника h_b: " + h_b + "\n" + "Высота треугольника h_c: " + h_c + "\n" +
                            "Медиана треугольника m_a: " + m_a + "\n" + "Медиана треугольника m_b: " + m_b + "\n" + "Медиана треугольника m_c: " + m_c + "\n" +
                            "Биссектриса треугольника l_a: " + l_a + "\n" + "Биссектриса треугольника l_b: " + l_b + "\n" + "Биссектриса треугольника l_c: " + l_c + "\n" +
                            "Средняя линия M_a: " + M_a + "\n" + "Средняя линия M_b: " + M_b + "\n" + "Средняя линия M_c: " + M_c + "\n" +
                            "Радиус вписанной окружности r: " + r + "\n" + "Радиус описанной окружности: " + R;
                }

                else result="Неправильный треугольник";
                break;
            case 1:
                alpha=Double.valueOf(String.valueOf(edit1.getText()));
                beta=Double.valueOf(String.valueOf(edit2.getText()));
                gama=180-alpha-beta;
                c=Double.valueOf(String.valueOf(edit3.getText()));
                a=(c*sin(Math.toRadians(beta+alpha)))/sin(Math.toRadians((beta)));
                b=(c*sin(Math.toRadians(beta)))/sin(Math.toRadians(alpha));
                p=(a+b+c)/2;
                S=sqrt(p*(p-a)*(p-b)*(p-c));
                m_a=sqrt(2*(b*b)+2*(c*c)-(a*a))/2;
                m_b=sqrt(2*(a*a)+2*(c*c)-(b*b) )/2;
                m_c=sqrt(2*(a*a)+2*(b*b)-(c*c) )/2;
                l_a=sqrt(b*c*(a+b+c)*(b+c-a))/(b+c);
                l_b=sqrt(a*c*(a+b+c)*(a+c-b))/(a+c);
                l_c=sqrt(a*b*(a+b+c)*(a+b-c))/(a+b);
                h_a=(2*sqrt(p*(p-a)*(p-b)*(p-c) ))/a;
                h_b=(2*sqrt(p*(p-a)*(p-b)*(p-c) ))/b;
                h_c=(2*sqrt(p*(p-a)*(p-b)*(p-c) ))/c;
                M_a=a/2;
                M_b=b/2;
                M_c=c/2;
                r=sqrt(((p-a)*(p-b)*(p-c))/p);
                R=a*b*c/(4*sqrt(p*(p-a)*(p-b)*(p-c)));
                if(((a+b>c)&&(a+c>b)&&(b+c>a))&&(Math.round(alpha+beta+gama)<=181)) {
                    result = "Сторона а: " + a + "\n" + "Сторона b: " + b + "\n" + "Сторона c: " + c + "\n" +
                            "Угол α: " + alpha + "\n" + "Угол β: " + beta + "\n" + "Угол γ: " + gama + "\n" +
                            "Площадь: " + S + "\n" + "Периметр: " + (p * 2) + "\n" +
                            "Высота треугольника h_a: " + h_a + "\n" + "Высота треугольника h_b: " + h_b + "\n" + "Высота треугольника h_c: " + h_c + "\n" +
                            "Медиана треугольника m_a: " + m_a + "\n" + "Медиана треугольника m_b: " + m_b + "\n" + "Медиана треугольника m_c: " + m_c + "\n" +
                            "Биссектриса треугольника l_a: " + l_a + "\n" + "Биссектриса треугольника l_b: " + l_b + "\n" + "Биссектриса треугольника l_c: " + l_c + "\n" +
                            "Средняя линия M_a: " + M_a + "\n" + "Средняя линия M_b: " + M_b + "\n" + "Средняя линия M_c: " + M_c + "\n" +
                            "Радиус вписанной окружности r: " + r + "\n" + "Радиус описанной окружности: " + R;
                }
                else result="Неправильный треугольник";
                break;
            case 2:
                a=Double.valueOf(String.valueOf(edit1.getText()));
                c=Double.valueOf(String.valueOf(edit2.getText()));
                alpha=Double.valueOf(String.valueOf(edit3.getText()));
                b=sqrt((a*a)+(c*c)-(2*a*c*cos(Math.toRadians(alpha)))+(c*c)-(a*a));
                beta = Math.toDegrees(acos((pow(a, 2) - pow(c, 2) + pow(b, 2)) / (2 * a * b)));
                gama = Math.toDegrees(acos((pow(b, 2) - pow(a, 2) + pow(c, 2)) / (2 * c * b)));
                p=(a+b+c)/2;
                S=sqrt(p*(p-a)*(p-b)*(p-c));
                m_a=sqrt(2*(b*b)+2*(c*c)-(a*a))/2;
                m_b=sqrt(2*(a*a)+2*(c*c)-(b*b))/2;
                m_c=sqrt(2*(a*a)+2*(b*b)-(c*c))/2;
                l_a=sqrt(b*c*(a+b+c)*(b+c-a))/(b+c);
                l_b=sqrt(a*c*(a+b+c)*(a+c-b))/(a+c);
                l_c=sqrt(a*b*(a+b+c)*(a+b-c))/(a+b);
                h_a=(2*sqrt(p*(p-a)*(p-b)*(p-c) ))/a;
                h_b=(2*sqrt(p*(p-a)*(p-b)*(p-c) ))/b;
                h_c=(2*sqrt(p*(p-a)*(p-b)*(p-c) ))/c;
                M_a=a/2;
                M_b=b/2;
                M_c=c/2;
                r=sqrt(((p-a)*(p-b)*(p-c))/p);
                R=a*b*c/(4*sqrt(p*(p-a)*(p-b)*(p-c)));
                if(((a+b>c)&&(a+c>b)&&(b+c>a))&&(Math.round(alpha+beta+gama)<=181)) {
                result="Сторона а: "+a+"\n"+"Сторона b: "+b+"\n"+"Сторона c: "+c+"\n"+
                        "Угол α: "+alpha+"\n"+"Угол β: "+beta+"\n"+"Угол γ: "+gama+"\n"+
                        "Площадь: "+S+"\n"+"Периметр: "+(p*2)+"\n"+
                        "Высота треугольника h_a: "+h_a+"\n"+"Высота треугольника h_b: "+h_b+"\n"+"Высота треугольника h_c: "+h_c+"\n"+
                        "Медиана треугольника m_a: "+m_a+"\n"+"Медиана треугольника m_b: "+m_b+"\n"+"Медиана треугольника m_c: "+m_c+"\n"+
                        "Биссектриса треугольника l_a: "+l_a+"\n"+"Биссектриса треугольника l_b: "+l_b+"\n"+"Биссектриса треугольника l_c: "+l_c+"\n"+
                        "Средняя линия M_a: "+M_a+"\n"+"Средняя линия M_b: "+M_b+"\n"+"Средняя линия M_c: "+M_c+"\n"+
                        "Радиус вписанной окружности r: "+r+"\n"+"Радиус описанной окружности: "+R;
                }
                else result="Неправильный треугольник";
                break;
            case 3:
                h=Double.valueOf(String.valueOf(edit1.getText()));
                a=Double.valueOf(String.valueOf(edit2.getText()));
                S=(a*h)/2;
                result="Площадь: "+S;
                break;
        }
    }
    //////////////////////////////////////////////////////////////////////////////////////
    void Rectangle_fill(){
        SpinerArr.add("Стороны"                );
        SpinerArr.add("Площадь и Сторону"      );
        SpinerArr.add("Диагональ и Сторону"    );
    }
    void Rectangle_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.rectangle_sides);
             edit1.setHint("Сторона а");
             edit1.setVisibility(View.VISIBLE);
             edit2.setHint("Сторона b");
             edit2.setVisibility(View.VISIBLE);
             edit3.setVisibility(View.INVISIBLE);
             edit4.setVisibility(View.INVISIBLE);
            break;
            case 1:Image1.setImageResource(R.drawable.rectangle_area_and_side_a);
                edit1.setHint("Площадь");
                edit1.setVisibility(View.VISIBLE);
                edit2.setHint("Сторона а");
                edit2.setVisibility(View.VISIBLE);
                edit3.setVisibility(View.INVISIBLE);
                edit4.setVisibility(View.INVISIBLE);
                break;
            case 2:Image1.setImageResource(R.drawable.diagonal_and_side_a);
                edit1.setHint("Диагональ");
                edit1.setVisibility(View.VISIBLE);
                edit2.setHint("Сторона а");
                edit2.setVisibility(View.VISIBLE);
                edit3.setVisibility(View.INVISIBLE);
                edit4.setVisibility(View.INVISIBLE);
                break;
        }

    }
    void Rectangle_result(){
        double a,s,b,p,alpha,beta,gama,omega,R,d;
        switch(pos_figure){
            case 0:
                a=Double.valueOf(String.valueOf(edit1.getText()));
                b=Double.valueOf(String.valueOf(edit2.getText()));
                s=a*b;
                alpha=2*Math.toDegrees(Math.atan(b/a));
                beta=2*Math.toDegrees(Math.atan(a/b));
                gama=alpha/2;
                omega=beta/2;
                p=2*(a+b);
                d=sqrt((a*a)+(b*b));
                R=d/2;
                result="Сторона а: "+a+"\n"+"Сторона b: "+b+"\n"+"Площадь: "+s+"\n"+"Периметр: "+p+"\n"+"Угол между диагоналями α: "+alpha+"\n"+"Угол между диагоналями β: "+beta+"\n"+"Угол от деления диагональю γ: "+gama+"\n"+"Угол от деления диагональю δ: "+omega+"\n"+"Радиус описанной окружности: "+R;
            break;
            case 1:
                s=Double.valueOf(String.valueOf(edit1.getText()));
                a=Double.valueOf(String.valueOf(edit2.getText()));
                b=s/a;
                alpha=2*Math.toDegrees(Math.atan(b/a));
                beta=2*Math.toDegrees(Math.atan(a/b));
                gama=alpha/2;
                omega=beta/2;
                p=2*(a+b);
                d=sqrt((a*a)+(b*b));
                R=d/2;
                result="Сторона а: "+a+"\n"+"Сторона b: "+b+"\n"+"Площадь: "+s+"\n"+"Периметр: "+p+"\n"+"Угол между диагоналями α: "+alpha+"\n"+"Угол между диагоналями β: "+beta+"\n"+"Угол от деления диагональю γ: "+gama+"\n"+"Угол от деления диагональю δ: "+omega+"\n"+"Радиус описанной окружности: "+R;
            break;
            case 2:
                d=Double.valueOf(String.valueOf(edit1.getText()));
                a=Double.valueOf(String.valueOf(edit2.getText()));
                b=sqrt((d*d)-(a*a));
                alpha=2*Math.toDegrees(Math.atan(b/a));
                beta=2*Math.toDegrees(Math.atan(a/b));
                gama=alpha/2;
                omega=beta/2;
                p=2*(a+b);
                s=a*b;
                R=d/2;
                result="Сторона а: "+a+"\n"+"Сторона b: "+b+"\n"+"Площадь: "+s+"\n"+"Периметр: "+p+"\n"+"Угол между диагоналями α: "+alpha+"\n"+"Угол между диагоналями β: "+beta+"\n"+"Угол от деления диагональю γ: "+gama+"\n"+"Угол от деления диагональю δ: "+omega+"\n"+"Радиус описанной окружности: "+R;
            break;
        }

    }
    //////////////////////////////////////////////////////////////////////////////////////
    void Trapezium_fill(){
        SpinerArr.add("Стороны"                 );
        SpinerArr.add("Среднюю линию и высоту"  );
    }
    void Trapezium_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.trapezoid_sides);
            edit1.setVisibility(View.VISIBLE);
            edit1.setHint("Сторона а");
            edit2.setVisibility(View.VISIBLE);
            edit2.setHint("Сторона b");
            edit3.setVisibility(View.VISIBLE);
            edit3.setHint("Сторона c");
            edit4.setVisibility(View.VISIBLE);
            edit4.setHint("Сторона d");
            break;
            case 1:Image1.setImageResource(R.drawable.trapezoid_middle_line_and_height);edit1.setVisibility(View.VISIBLE);
                edit1.setVisibility(View.VISIBLE);
                edit1.setHint("Средняя линия");
                edit2.setVisibility(View.VISIBLE);
                edit2.setHint("Высота");
                edit3.setVisibility(View.INVISIBLE);
                edit4.setVisibility(View.INVISIBLE);
                break;
        }
    }
    void Trapezium_result(){
        double a=0,b=0,c=0,d=0,S=0,p=0,h=0,m=0,d_1=0,d_2=0,r=0,R=0;
        switch(pos_figure){
            case 0:
                a=Double.valueOf(String.valueOf(edit1.getText()));
                b=Double.valueOf(String.valueOf(edit2.getText()));
                c=Double.valueOf(String.valueOf(edit3.getText()));
                d=Double.valueOf(String.valueOf(edit4.getText()));
                h=sqrt((a*a)-pow(((((d-b)*(d-b))+(a*a)-(c*c))/2*(d-b)),2));
                p=a+b+c+d;
                m=(b+d)/2;
                d_1=sqrt(pow(c,2)+(d*b)-(d*(pow(c,2)-pow(a,2)))/(d-b));
                d_2=sqrt(pow(a,2)+(d*b)-(d*(pow(c,2)-pow(a,2)))/(d-b));
                S=(b+d)*h/2;
                result="Сторона а: "+a+"\n"+"Сторона b: "+b+"\n"+"Сторона c: "+c+"\n"+"Сторона d: "+d+"\n"+"Периметр: "+p+"\n"+
                        "Высота: "+h+"\n"+"Средняя линия: "+m+"\n"+
                        "Диагональ d_1: "+d_1+"\n"+"Диагональ d_2: "+d_2+"\n"+"Площадь: "+S;
                break;
            case 1:
                m=Double.valueOf(String.valueOf(edit1.getText()));
                h=Double.valueOf(String.valueOf(edit2.getText()));
                S=m*h;
                result="Площадь: "+S;
            break;
        }


    }
    //////////////////////////////////////////////////////////////////////////////////////
    void Parallelogram_fill() {
        SpinerArr.add("Стороны и высоту");
        SpinerArr.add("Стороны и угол");
        SpinerArr.add("Высоту и угол");
    }
    void Parallelogram_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.parallelogram_side_and_height);
            edit1.setHint("Сторона а");
            edit1.setVisibility(View.VISIBLE);
            edit2.setHint("Сторона b");
            edit2.setVisibility(View.VISIBLE);
            edit3.setHint("Высота h_b");
            edit3.setVisibility(View.VISIBLE);
            edit4.setVisibility(View.INVISIBLE);
            break;
            case 1:Image1.setImageResource(R.drawable.parallelogram_sides_and_angle_a);
                edit1.setHint("Сторона а");
                edit1.setVisibility(View.VISIBLE);
                edit2.setHint("Сторона b");
                edit2.setVisibility(View.VISIBLE);
                edit3.setHint("Угол α");
                edit3.setVisibility(View.VISIBLE);
                edit4.setVisibility(View.INVISIBLE);
                break;
            case 2:Image1.setImageResource(R.drawable.parallelogram_heights_and_angle_a);
                edit1.setHint("Высота h_a");
                edit1.setVisibility(View.VISIBLE);
                edit2.setHint("Высота h_b");
                edit2.setVisibility(View.VISIBLE);
                edit3.setHint("Угол α");
                edit3.setVisibility(View.VISIBLE);
                edit4.setVisibility(View.INVISIBLE);
            break;

        }
    }
    void Parallelogram_result(){
        double a,b,d_1,d_2,S,p,h_a,h_b,alpha,gama,beta,l1,l2;
        switch(pos_figure){
            case 0:
                a=Double.valueOf(String.valueOf(edit1.getText()));
                b=Double.valueOf(String.valueOf(edit2.getText()));
                h_b=Double.valueOf(String.valueOf(edit3.getText()));
                p=2*(a+b);
                S=b*h_b;
                h_a=S/a;
                alpha=toDegrees(asin(h_b/a));
                beta=180-alpha;
                d_1=sqrt((a*a)+(b*b)-2*a*b*cos(Math.toRadians(beta)) );
                d_2=sqrt((a*a)+(b*b)-2*a*b*cos(Math.toRadians(alpha) ));
                l1=a*sqrt(2-2*cos(Math.toRadians(beta)));
                l2= b*sqrt(2-2*cos(Math.toRadians(alpha)));
                result="Сторона а: "+a+"\n"+"Сторона b: "+b+"\n"+"Угол α: " + alpha + "\n" + "Угол β: " + beta + "\n"+
                        "Диагональ d_1: "+d_1+"\n"+"Диагональ d_2: "+d_2+"\n"+"Биссектриса l_α: "+l1+"\n"+"Биссектриса l_β: "+l2+"\n"+
                        "Площадь: "+S+"\n"+"Периметр: "+p+"\n"+
                        "Высота h_а: "+h_a+"\n"+"Высота h_b: "+h_b+"\n";
                break;
            case 1:
                a=Double.valueOf(String.valueOf(edit1.getText()));
                b=Double.valueOf(String.valueOf(edit2.getText()));
                alpha=Double.valueOf(String.valueOf(edit3.getText()));;
                h_b=a*sin(Math.toRadians(alpha));
                p=2*(a+b);
                S=b*h_b;
                h_a=S/a;
                beta=180-alpha;
                d_1=sqrt((a*a)+(b*b)-2*a*b*cos(Math.toRadians(beta)) );
                d_2=sqrt((a*a)+(b*b)-2*a*b*cos(Math.toRadians(alpha) ));
                l1=a*sqrt(2-2*cos(Math.toRadians(beta)));
                l2= b*sqrt(2-2*cos(Math.toRadians(alpha)));
                result="Сторона а: "+a+"\n"+"Сторона b: "+b+"\n"+"Угол α: " + alpha + "\n" + "Угол β: " + beta + "\n"+
                        "Диагональ d_1: "+d_1+"\n"+"Диагональ d_2: "+d_2+"\n"+"Биссектриса l_α: "+l1+"\n"+"Биссектриса l_β: "+l2+"\n"+
                        "Площадь: "+S+"\n"+"Периметр: "+p+"\n"+
                        "Высота h_а: "+h_a+"\n"+"Высота h_b: "+h_b+"\n";
                break;
            case 2:
                h_a=Double.valueOf(String.valueOf(edit1.getText()));
                h_b=Double.valueOf(String.valueOf(edit2.getText()));
                alpha=Double.valueOf(String.valueOf(edit3.getText()));
                a=h_b/sin(toRadians(alpha));
                b=h_a/sin(toRadians(alpha));
                p=2*(a+b);
                S=b*h_b;
                beta=180-alpha;
                d_1=sqrt((a*a)+(b*b)-2*a*b*cos(Math.toRadians(beta)));
                d_2=sqrt((a*a)+(b*b)-2*a*b*cos(Math.toRadians(alpha)));
                l1=a*sqrt(2-2*cos(Math.toRadians(beta)));
                l2= b*sqrt(2-2*cos(Math.toRadians(alpha)));
                result="Сторона а: "+a+"\n"+"Сторона b: "+b+"\n"+"Угол α: " + alpha + "\n" + "Угол β: " + beta + "\n"+
                        "Диагональ d_1: "+d_1+"\n"+"Диагональ d_2: "+d_2+"\n"+"Биссектриса l_α: "+l1+"\n"+"Биссектриса l_β: "+l2+"\n"+
                        "Площадь: "+S+"\n"+"Периметр: "+p+"\n"+
                        "Высота h_а: "+h_a+"\n"+"Высота h_b: "+h_b+"\n";
                break;

        }
    }
    //////////////////////////////////////////////////////////////////////////////////////
    void Ring_fill(){
        SpinerArr.add("Радиус"        );
        SpinerArr.add("Диаметр"       );
        SpinerArr.add("Окружность"    );
        SpinerArr.add("Сектор кольца" );
    }
    void Ring_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.ring_radius);
            edit1.setHint("Внешний радиус кольца R");
             edit1.setVisibility(View.VISIBLE);
             edit2.setHint("Внутренний радиус кольца r");
             edit2.setVisibility(View.VISIBLE);
             edit3.setVisibility(View.INVISIBLE);
             edit4.setVisibility(View.INVISIBLE);break;
            case 1:Image1.setImageResource(R.drawable.ring_diameter);
            edit1.setHint("Диаметр кольца D");
             edit1.setVisibility(View.VISIBLE);
             edit2.setHint("Диаметр кольца d");
             edit2.setVisibility(View.VISIBLE);
             edit3.setVisibility(View.INVISIBLE);
             edit4.setVisibility(View.INVISIBLE);break;
            case 2:Image1.setImageResource(R.drawable.ring_circle);
            edit1.setHint("Окружность кольца P");
             edit1.setVisibility(View.VISIBLE);
             edit2.setHint("Окружность кольца p");
             edit2.setVisibility(View.VISIBLE);
             edit3.setVisibility(View.INVISIBLE);
             edit4.setVisibility(View.INVISIBLE);break;
            case 3:Image1.setImageResource(R.drawable.ring_ring_sector);
            edit1.setHint("Внешний радиус кольца R");
             edit1.setVisibility(View.VISIBLE);
             edit2.setHint("Внутренний радиус кольца r");
             edit2.setVisibility(View.VISIBLE);
             edit3.setVisibility(View.VISIBLE);
             edit3.setHint("Угол сектора кольца α");
             edit4.setVisibility(View.INVISIBLE);break;
        }
    }
    void Ring_result(){
        double R,r,d,D,p,P,S,h;
        switch (pos_figure){
            case 0:
                R=Double.valueOf(String.valueOf(edit1.getText()));
                r=Double.valueOf(String.valueOf(edit2.getText()));
                D=2*R;
                d=2*r;
                p=2*Math.PI*r;
                P=2*Math.PI*R;
                S=Math.PI*(pow(R,2)-pow(r,2));
                h=(R-r)/2;
                result="Внешний радиус кольца R :"+R+"\n" +
                        "Внутренний радиус кольца r:"+r+"\n"+
                        "Площадь кольца S :"+S+"\n"+
                        "Окружность кольца P :"+P+"\n"+
                        "Окружность кольца p :"+p+"\n"+
                        "Диаметр кольца D :"+D+"\n"+
                        "Диаметр кольца d :"+d+"\n"+
                        "Ширина кольца h :"+h;
                break;
            case 1:
                D=Double.valueOf(String.valueOf(edit1.getText()));
                d=Double.valueOf(String.valueOf(edit2.getText()));
                R=D/2;
                r=d/2;
                p=2*Math.PI*r;
                P=2*Math.PI*R;
                S=Math.PI*(pow(R,2)-pow(r,2));
                h=(R-r)/2;
                result="Внешний радиус кольца R :"+R+"\n" +
                        "Внутренний радиус кольца r:"+r+"\n"+
                        "Площадь кольца S :"+S+"\n"+
                        "Окружность кольца P :"+P+"\n"+
                        "Окружность кольца p :"+p+"\n"+
                        "Диаметр кольца D :"+D+"\n"+
                        "Диаметр кольца d :"+d+"\n"+
                        "Ширина кольца h :"+h;
                break;
            case 2:
                p=Double.valueOf(String.valueOf(edit2.getText()));
                P=Double.valueOf(String.valueOf(edit1.getText()));
                d=p/PI;
                D=P/PI;
                R=D/2;
                r=d/2;
                S=Math.PI*(pow(R,2)-pow(r,2));
                h=(R-r)/2;
                result="Внешний радиус кольца R :"+R+"\n" +
                        "Внутренний радиус кольца r:"+r+"\n"+
                        "Площадь кольца S :"+S+"\n"+
                        "Окружность кольца P :"+P+"\n"+
                        "Окружность кольца p :"+p+"\n"+
                        "Диаметр кольца D :"+D+"\n"+
                        "Диаметр кольца d :"+d+"\n"+
                        "Ширина кольца h :"+h;
                break;
            case 3:
                double alpha;
                R=Double.valueOf(String.valueOf(edit1.getText()));
                r=Double.valueOf(String.valueOf(edit2.getText()));
                alpha=Double.valueOf(String.valueOf(edit3.getText()));
                p=2*PI*r*alpha/(360);
                P=R*toRadians(alpha);
                S=((pow(R,2)-pow(r,2))*toRadians(alpha))/2;
                result="Площадь сектора кольца :"+S+"\n"+
                        "Длина дуги кольца a:"+P+"\n"+
                        "Длина дуги кольца b:"+p;
        }
    }
    //////////////////////////////////////////////////////////////////////////////////////
    void Circle_fill(){
        SpinerArr.add("Диаметр" );
        SpinerArr.add("Радиус"  );
        SpinerArr.add("Площадь" );
        SpinerArr.add("Периметр" );
    }
    void Circle_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.circle_diameter);
                    edit1.setHint("Диаметр");
                    edit1.setVisibility(View.VISIBLE);
                    edit2.setVisibility(View.INVISIBLE);
                    edit3.setVisibility(View.INVISIBLE);
                    edit4.setVisibility(View.INVISIBLE);
                    break;
            case 1:Image1.setImageResource(R.drawable.circle_radius);
                    edit1.setHint("Радиус");
                    edit1.setVisibility(View.VISIBLE);
                    edit2.setVisibility(View.INVISIBLE);
                    edit3.setVisibility(View.INVISIBLE);
                    edit4.setVisibility(View.INVISIBLE);
                    break;
            case 2:Image1.setImageResource(R.drawable.circle_area);
                    edit1.setHint("Площадь");
                    edit1.setVisibility(View.VISIBLE);
                    edit2.setVisibility(View.INVISIBLE);
                    edit3.setVisibility(View.INVISIBLE);
                    edit4.setVisibility(View.INVISIBLE);
                    break;
            case 3:Image1.setImageResource(R.drawable.circle_circuit);
                    edit1.setHint("Периметр");
                    edit1.setVisibility(View.VISIBLE);
                    edit2.setVisibility(View.INVISIBLE);
                    edit3.setVisibility(View.INVISIBLE);
                    edit4.setVisibility(View.INVISIBLE);
                    break;

        }
    }
    void Circle_result(){
        double p,s,r,d;
         switch(pos_figure){
             case 0:

             break;
         }
    }
    //////////////////////////////////////////////////////////////////////////////////////
    void Regular_Polygon_fill(){
        SpinerArr.add("Стороны"                    );
        SpinerArr.add("Площадь"                    );
        SpinerArr.add("Угол и сторону"             );
        SpinerArr.add("Радиус вписанной окружности");
        SpinerArr.add("Радиус описанной окружности");
    }
    void Regular_Polygon_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.regular_polygon_side);break;
            case 1:Image1.setImageResource(R.drawable.regular_polygon_area);break;
            case 2:Image1.setImageResource(R.drawable.regular_polygon_angle);break;
            case 3:Image1.setImageResource(R.drawable.regular_polygon_radius_of_inscribed_circle);break;
            case 4:Image1.setImageResource(R.drawable.regular_polygon_radius_of_circle);break;
        }
    }
    void Regular_Polygon_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Circular_Sector_fill(){
        SpinerArr.add("Радиус и угол"       );
        SpinerArr.add("Длину дуги и радиус" );
        SpinerArr.add("Угол и длину дуги"   );
    }
    void Circular_Sector_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.circular_sector_radius_and_angle);break;
            case 1:Image1.setImageResource(R.drawable.circular_sector_arc_length_and_radius);break;
            case 2:Image1.setImageResource(R.drawable.circular_sector_angle_and_arc_length);break;
        }
    }
    void Circular_Sector_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Rhombus_fill(){
        SpinerArr.add("Сторону и высоту"    );
        SpinerArr.add("Площадь и угол"      );
        SpinerArr.add("Площадь и диагональ" );
        SpinerArr.add("Сторону и угол"      );
        SpinerArr.add("Диагонали"           );
        SpinerArr.add("Площадь и сторону"   );
        SpinerArr.add("Диагональ и сторону" );
        SpinerArr.add("Радиус и сторону"    );
        SpinerArr.add("Радиус и угол"       );
    }
    void Rhombus_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.rhombus_side_and_height);break;
            case 1:Image1.setImageResource(R.drawable.rhombus_area_and_angle_a);break;
            case 2:Image1.setImageResource(R.drawable.rhombus_area_and_diagonal_d1);break;
            case 3:Image1.setImageResource(R.drawable.rhombus_side_and_angle_a);break;
            case 4:Image1.setImageResource(R.drawable.rhombus_diagonals);break;
            case 5:Image1.setImageResource(R.drawable.rhombus_area_and_side);break;
            case 6:Image1.setImageResource(R.drawable.rhombus_diagonal_d1_and_side);break;
            case 7:Image1.setImageResource(R.drawable.rhombus_radius_and_side);break;
            case 8:Image1.setImageResource(R.drawable.rhombus_area_and_angle_a);break;
        }
    }
    void Rhombus_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Cube_fill(){
        SpinerArr.add("Ребро"                       );
        SpinerArr.add("Площадь куба"                );
        SpinerArr.add("Площадь боковой поверхности" );
        SpinerArr.add("Объём"                       );
        SpinerArr.add("Периметр стороны"            );
        SpinerArr.add("Диагональ куба"              );
        SpinerArr.add("Диагональ стороны"           );
        SpinerArr.add("Радиус вписанной сферы"      );
        SpinerArr.add("Радиус описанной сферы"      );
    }
    void Cube_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.cube_edge);break;
            case 1:Image1.setImageResource(R.drawable.cube_area_cube);break;
            case 2:Image1.setImageResource(R.drawable.cube_area_side);break;
            case 3:Image1.setImageResource(R.drawable.cube_volume);break;
            case 4:Image1.setImageResource(R.drawable.cube_perimeter_side);break;
            case 5:Image1.setImageResource(R.drawable.cube_diagonal_cube);break;
            case 6:Image1.setImageResource(R.drawable.cube_diagonal_side);break;
            case 7:Image1.setImageResource(R.drawable.cube_radius_of_inscribed_sphere);break;
            case 8:Image1.setImageResource(R.drawable.cube_radius_of_sphere);break;
        }
    }
    void Cube_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Sphere_fill(){
        SpinerArr.add("Радиус"              );
        SpinerArr.add("Объём"               );
        SpinerArr.add("Площадь поверхности" );
        SpinerArr.add("Диаметр"             );
        SpinerArr.add("Окружнесть"          );
        SpinerArr.add("Шаровой сегмент"     );
        SpinerArr.add("Шаровой сектор"      );
        SpinerArr.add("Шаровой слой"        );
    }
    void Sphere_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.sphere_radius);break;
            case 1:Image1.setImageResource(R.drawable.sphere_volume);break;
            case 2:Image1.setImageResource(R.drawable.sphere_area);break;
            case 3:Image1.setImageResource(R.drawable.sphere_diameter);break;
            case 4:Image1.setImageResource(R.drawable.sphere_circle);break;
            case 5:Image1.setImageResource(R.drawable.volume_sphere_segment);break;
            case 6:Image1.setImageResource(R.drawable.volume_sphere_sector);break;
            case 7:Image1.setImageResource(R.drawable.volume_sphere_layer);break;
        }
    }
    void Sphere_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Parallelepiped_fill(){
        SpinerArr.add("Рёбра"     );
        SpinerArr.add("Диагональ" );
    }
    void Parallelepiped_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.parallelepiped_edge);break;
            case 1:Image1.setImageResource(R.drawable.parallelepiped_diagonal);break;
        }
    }
    void Parallelepiped_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Cone_fill(){
        SpinerArr.add("Радиус и образующую"            );
        SpinerArr.add("Радиус и высоту"                );
        SpinerArr.add("Образующую и высоту"            );
        SpinerArr.add("Объём и высоту"                 );
        SpinerArr.add("Угол раствора и образующую"     );
        SpinerArr.add("Угол раствора и высоту"         );
        SpinerArr.add("Угол раствора и радиус"         );
        SpinerArr.add("Площадь основания и образующую" );
        SpinerArr.add("Площадь основания и высоту"     );
    }
    void Cone_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.cone_radius_and_forming);break;
            case 1:Image1.setImageResource(R.drawable.cone_radius_and_height);break;
            case 2:Image1.setImageResource(R.drawable.cone_forming_and_height);break;
            case 3:Image1.setImageResource(R.drawable.cone_volume_and_height);break;
            case 4:Image1.setImageResource(R.drawable.cone_opening_angle_and_forming);break;
            case 5:Image1.setImageResource(R.drawable.cone_opening_angle_and_height);break;
            case 6:Image1.setImageResource(R.drawable.cone_opening_angle_and_radius);break;
            case 7:Image1.setImageResource(R.drawable.cone_footprint_and_forming);break;
            case 8:Image1.setImageResource(R.drawable.cone_footprint_and_height);break;
        }
    }
    void Cone_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Prism_fill(){
        SpinerArr.add("Рёбра"                          );
        SpinerArr.add("Рёбра и высоту"                 );
        SpinerArr.add("Диагональ и ребро"              );
        SpinerArr.add("Радиус описанной сферы и ребро" );
    }
    void Prism_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.prism_edges);break;
            case 1:Image1.setImageResource(R.drawable.prism_edge_and_height);break;
            case 2:Image1.setImageResource(R.drawable.prism_diagonal_and_edge_a);break;
            case 3:Image1.setImageResource(R.drawable.radius_sphere_and_edge_a);break;

        }
    }
    void Prism_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Pyramid_fill(){
        SpinerArr.add("Высоту и сторону основания"  );
        SpinerArr.add("Ребро и сторону основания"   );
        SpinerArr.add("Апофему и сторону основания" );
        SpinerArr.add("Периметр и апофему"          );
        SpinerArr.add("Площадь и высоту"            );
    }
    void Pyramid_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.pyramid_side_and_height);break;
            case 1:Image1.setImageResource(R.drawable.pyramid_edge_and_side);break;
            case 2:Image1.setImageResource(R.drawable.pyramid_apothem_and_side);break;
            case 3:Image1.setImageResource(R.drawable.pyramid_perimeter_and_apothem);break;
            case 4:Image1.setImageResource(R.drawable.pyramid_area_and_height);break;

        }
    }
    void Pyramid_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Torus_fill(){
        SpinerArr.add("Радиус"     );
        SpinerArr.add("Окружность" );
    }
    void Torus_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.torus_radius);break;
            case 1:Image1.setImageResource(R.drawable.torus_circle);break;
        }
    }
    void Torus_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Tetrahedron_fill(){
        SpinerArr.add("Ребро"                  );
        SpinerArr.add("Объём"                  );
        SpinerArr.add("Площадь"                );
        SpinerArr.add("Длину ребёр"            );
        SpinerArr.add("Высоту"                 );
        SpinerArr.add("Радиус вписанной сферы" );
        SpinerArr.add("Радиус описанной сферы" );
    }
    void Tetrahedron_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.tetrahedron_edge);break;
            case 1:Image1.setImageResource(R.drawable.tetrahedron_volume);break;
            case 2:Image1.setImageResource(R.drawable.tetrahedron_area);break;
            case 3:Image1.setImageResource(R.drawable.tetrahedron_edges);break;
            case 4:Image1.setImageResource(R.drawable.tetrahedron_height);break;
            case 5:Image1.setImageResource(R.drawable.tetrahedron_radius_inscribed_sphere);break;
            case 6:Image1.setImageResource(R.drawable.tetrahedron_radius_sphere);break;

        }
    }
    void Tetrahedron_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Cylinder_fill(){
        SpinerArr.add("Радиус и высоту"            );
        SpinerArr.add("Радиус и объём"             );
        SpinerArr.add("Радиус и диагональ"         );
        SpinerArr.add("Высоту и площадь основания" );
        SpinerArr.add("Высоту и диагональ"         );
        SpinerArr.add("Диаметр и высоту"           );
        SpinerArr.add("Диаметр и объём"            );
        SpinerArr.add("Диаметр и диагональ"        );
    }
    void Cylinder_image(){
        switch(pos_figure){
            case 0:Image1.setImageResource(R.drawable.cylinder_radius_and_height);break;
            case 1:Image1.setImageResource(R.drawable.cylinder_radius_and_volume);break;
            case 2:Image1.setImageResource(R.drawable.cylinder_radius_and_diagonal);break;
            case 3:Image1.setImageResource(R.drawable.cylinder_height_and_footprint);break;
            case 4:Image1.setImageResource(R.drawable.cylinder_height_and_diagonal);break;
            case 5:Image1.setImageResource(R.drawable.cylinder_diameter_and_height);break;
            case 6:Image1.setImageResource(R.drawable.cylinder_diameter_and_volume);break;
            case 7:Image1.setImageResource(R.drawable.cylinder_diameter_and_diagonal);break;

        }
    }
    void Cylinder_result(){}
    //////////////////////////////////////////////////////////////////////////////////////
    void Spinner(){
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, SpinerArr);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setAdapter(adapter);
        // заголовок
        spinner.setPrompt("Title");
        // выделяем элемент
        spinner.setSelection(0);
        // устанавливаем обработчик нажатия
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // показываем позиция нажатого элемента
                pos_figure=position;
                Figure_image();
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
    }
    public void onMyButtonClick(View view) {
        Toast toast;

        Figure_result();
        i.putExtra("result", result);
        startActivity(i);


        }


    void findViews(){
        Image1=findViewById(R.id.imageView3);
        edit1 = findViewById(R.id.editText);
        edit2 = findViewById(R.id.editText2);
        edit3 = findViewById(R.id.editText3);
        edit4 = findViewById(R.id.editText4);
    }
}
