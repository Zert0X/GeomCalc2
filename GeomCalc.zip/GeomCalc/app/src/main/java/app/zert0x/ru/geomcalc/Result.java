package app.zert0x.ru.geomcalc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import app.zert0x.ru.geomcalc.Choose.*;

import static app.zert0x.ru.geomcalc.MainActivity.figure;

public class Result extends AppCompatActivity {
TextView result_txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        result_txt=findViewById(R.id.result);
        Intent intent = getIntent();
        String result = intent.getStringExtra("result");
        switch(figure){
            case "Квадрат":                     ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.square          );break;
            case "Прямоугольник":               ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.rectangle       );break;
            case "Треугольник":                 ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.triangle        );break;
            case "Трапеция":                    ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.trapezoid       );break;
            case "Параллелограмм":              ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.parallelogram   );break;
            case "Кольцо":                      ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.ring            );break;
            case "Круг":                        ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.circle          );break;
            case "Правильный многоугольник":    ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.regular_polygon );break;
            case "Сектор круга":                ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.circular_sector );break;
            case "Ромб":                        ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.rhombus         );break;
            case "Куб":                         ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.cube            );break;
            case "Шар":                         ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.sphere          );break;
            case "Параллелепипед":              ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.parallelepiped  );break;
            case "Конус":                       ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.cone            );break;
            case "Призма":                      ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.prism           );break;
            case "Пирамида":                    ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.pyramid         );break;
            case "Тор":                         ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.torus           );break;
            case "Тетраэдр":                    ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.tetrahedron     );break;
            case "Цилиндр":                     ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.cylinder        );break;
        }

        result_txt.setText(result);
    }
}
