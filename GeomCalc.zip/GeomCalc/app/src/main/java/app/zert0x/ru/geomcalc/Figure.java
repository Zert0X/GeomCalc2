package app.zert0x.ru.geomcalc;

public class Figure {
    String name;
    int image;
    Figure(String _name, int _image){
        this.name=_name;
        this.image=_image;
    }
}
