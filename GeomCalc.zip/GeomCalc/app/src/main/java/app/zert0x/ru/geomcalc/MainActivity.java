package app.zert0x.ru.geomcalc;

import android.content.Intent;
import android.support.constraint.solver.widgets.Rectangle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toolbar;

import java.util.ArrayList;

import app.zert0x.ru.geomcalc.figure_adapter;
public class MainActivity extends AppCompatActivity {
ListView List1;
static int pos;
static String figure;
    public static ArrayList<Figure> FigureArr = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViews();
        figure_adapter figureAdapter;
        FigureArr.clear();
        figureAdapter = new figure_adapter(this, R.layout.activity_figure_item, FigureArr);
        List1.setAdapter(figureAdapter);
        Fill();
        List1.setAdapter(figureAdapter);
        final Intent intent;
        intent = new Intent(this, Choose.class);
        List1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                figure = FigureArr.get(position).name;
                pos = position;
                startActivity(intent);
            }
        });
    }
    private void findViews(){
        List1 = findViewById(R.id.List);
    }
    public void Fill(){

        FigureArr.add(new Figure("Квадрат"                  ,R.drawable.square          ));
        FigureArr.add(new Figure("Прямоугольник"            ,R.drawable.rectangle       ));
        FigureArr.add(new Figure("Треугольник"              ,R.drawable.triangle        ));
        FigureArr.add(new Figure("Трапеция"                 ,R.drawable.trapezoid       ));
        FigureArr.add(new Figure("Параллелограмм"           ,R.drawable.parallelogram   ));
        FigureArr.add(new Figure("Кольцо"                   ,R.drawable.ring            ));
        FigureArr.add(new Figure("Круг"                     ,R.drawable.circle          ));
        FigureArr.add(new Figure("Правильный многоугольник *WIP*" ,R.drawable.regular_polygon ));
        FigureArr.add(new Figure("Сектор круга *WIP*"             ,R.drawable.circular_sector ));
        FigureArr.add(new Figure("Ромб *WIP*"                     ,R.drawable.rhombus         ));
        FigureArr.add(new Figure("Куб"                      ,R.drawable.cube            ));
        FigureArr.add(new Figure("Шар *WIP*"                      ,R.drawable.sphere          ));
        FigureArr.add(new Figure("Параллелепипед"           ,R.drawable.parallelepiped  ));
        FigureArr.add(new Figure("Конус *WIP*"                    ,R.drawable.cone            ));
        FigureArr.add(new Figure("Призма"                   ,R.drawable.prism           ));
        FigureArr.add(new Figure("Пирамида *WIP*"                 ,R.drawable.pyramid         ));
        FigureArr.add(new Figure("Тор *WIP*"                      ,R.drawable.torus           ));
        FigureArr.add(new Figure("Тетраэдр *WIP*"                 ,R.drawable.tetrahedron     ));
        FigureArr.add(new Figure("Цилиндр *WIP*"                  ,R.drawable.cylinder        ));


    }

}
