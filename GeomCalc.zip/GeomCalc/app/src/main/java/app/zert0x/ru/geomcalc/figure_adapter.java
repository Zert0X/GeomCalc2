package app.zert0x.ru.geomcalc;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class figure_adapter extends ArrayAdapter<Figure> {
    Context ctx;
    int layout;
    LayoutInflater lInflater;
    ArrayList<Figure> objects;

    figure_adapter(Context context, int resource, ArrayList<Figure> products) {
        super(context,resource,products);
        ctx = context;
        objects = products;
        layout = resource;
        lInflater = LayoutInflater.from(context);
    }

    // кол-во элементов
    @Override
    public int getCount() {
        return objects.size();
    }

    // элемент по позиции
    @Override
    public Figure getItem(int position) {
        return objects.get(position);
    }

    // id по позиции
    @Override
    public long getItemId(int position) {
        return position;
    }

    // пункт списка
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // используем созданные, но не используемые view


        View view = lInflater.inflate(R.layout.activity_figure_item, parent, false);


        Figure p = getItem(position);
        ((TextView) view.findViewById(R.id.textView)).setText(p.name);
        ((ImageView) view.findViewById(R.id.imageView)).setImageResource(p.image);
        return view;
    }
}
